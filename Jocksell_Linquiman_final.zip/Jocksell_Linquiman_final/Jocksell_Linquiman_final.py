#productos = {modelo: [marca, pantalla, RAM, disco, GB de DD, procesador, video],]

productos = {
'8475HD': ['HP', 15.6, '8GB', 'DD', '1T', 'Intel Core i5', 'Nvidia GTX1050'],
'2175HD': ['LENOVO', 14, '4GB', 'SSD', '512GB', 'Intel Core i5', 'Nvidia GTX1050'],
'JjfFHD': ['ASUS', 14, '16GB', 'SSD', '256GB', 'Intel Core i7', 'Nvidia RTX2080Ti'],
'fgdxFHD': ['HP', 15.6, '8GB', 'DD', '1T', 'Intel Core i3', 'integrada'],
'GF75HD': ['ASUS', 15.6, '8GB', 'DD', '1T', 'Intel Core i7', 'Nvidia GTX1050'],
'123FHD': ['LENOVO', 14, '6GB', 'DD', '1T', 'AMD Ryzen 5', 'integrada'],
'342FHD': ['LENOVO', 15.6, '8GB', 'DD', '1T', 'AMD Ryzen 7', 'Nvidia GTX1050'],
'UWU131HD': ['DELL', 15.6, '8GB', 'DD', '1T', 'AMD Ryzen 3', 'Nvidia GTX1050'], 
}

#stock = {modelo: [precio, stock], ...]
stock = {
'8475HD': [387990, 10], '2175HD': [327990, 4], 'JjfFHD': [424990, 1],
'fgdxFHD': [664990, 21], '123FHD': [290890, 32], '342FHD': [444990, 7],
'GF75HD': [749990, 2], 'UWU131HD': [349990, 1], 'FS1230HD': [249990, 0],
}


print("\n***MENU PRINCIPAL***"),
print("1. Stock marca"),
print("2. Busqueda por precio"),
print("3. Actualias precio"),
print("4. Salir"),

opc = input("Seleccione un opcion")
while opc =="":
    print("Ingrese nuevamente la opcion")
if opc == "1":
    marca =input("Ingrese marca a consultar: ")


elif opc == "2":
     precio_min = input(int("Ingrese precio mínimo"))
     precio_max = input(int("Ingrese precio máximo"))


elif opc == "3":
     modelo = input("Ingrese modelo a actualizar: ")
     nuevo_precio = input(int("Ingrese precio nuevo")) 


else: 
     opc == "4"
     print("Bye")   
break

#APUNTE A UN 3.8
#LO INTENTE pero se me olvido todo 






       




